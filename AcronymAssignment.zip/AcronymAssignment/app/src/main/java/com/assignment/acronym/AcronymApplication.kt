package com.assignment.acronym

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AcronymApplication : Application()