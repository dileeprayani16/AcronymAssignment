package com.assignment.acronym.ui.fragment

import androidx.fragment.app.Fragment

open class BaseFragment: Fragment()
