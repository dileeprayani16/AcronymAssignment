package com.assignment.network.remote

import javax.inject.Inject

class RemoteDataSource @Inject constructor(
    private val remoteAPIService: RemoteAPIService
) {
    suspend fun getByShortForm(sf: String) = remoteAPIService.getByShortForm(sf)
    suspend fun getByLongForm(lf: String) = remoteAPIService.getByLongForm(lf)
}